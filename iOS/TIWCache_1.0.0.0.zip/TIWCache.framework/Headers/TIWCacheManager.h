#import <Foundation/Foundation.h>

@interface TIWCacheConfig : NSObject
@property (nonatomic, strong) NSString *dir;
@property (nonatomic, assign) NSInteger sdkAppId;
@end

@interface TIWCacheManager : NSObject
+ (instancetype)shareInstance;
+ (void)destroyInstance;
- (void)setConfig:(TIWCacheConfig *)config;
- (NSString *)getResourcePath:(NSString *)url;
+ (NSString *)getVersion;
@end
