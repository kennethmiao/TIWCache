//
//  TIWWebView.h
//  TIWCache
//
//  Created by 缪少豪 on 2020/10/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TIWWebView : WKWebView

@end

NS_ASSUME_NONNULL_END
